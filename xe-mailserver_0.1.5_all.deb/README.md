# xe-mailserver
Metapackage for xundeenergie mailserver build with exim4, dovecot and spamassassin
